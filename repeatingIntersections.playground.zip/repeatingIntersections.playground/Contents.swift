import UIKit

func repeatingIntersectionsIn(arrayOne: [Int], arrayTwo: [Int]) -> [Int] {

    var intersectionsInArrays: [Int] = []
    let setOne = Set(arrayOne)
    let setTwo = Set(arrayTwo)

    for numbers in setOne {
        if setTwo.contains(numbers) {
            var numberOfRepeat = min(arrayOne.filter{ $0 == numbers }.count,
                                     arrayTwo.filter{ $0 == numbers }.count)

            while numberOfRepeat > 0 {
                numberOfRepeat -= 1
                intersectionsInArrays.append(numbers)
            }
        }
    }

    return intersectionsInArrays
}





